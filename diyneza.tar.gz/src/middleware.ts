import { type NextRequest } from "next/server";
import { updateSession } from "@/utils/supabase/middleware";

export async function middleware(request: NextRequest) {
  return await updateSession(request);
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - images/ and logos/ folders
     */
    "/((?!_next/static|_next/image|favicon.ico|images|logos|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
